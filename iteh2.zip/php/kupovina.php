<?php

class Knjiga
{
	public $kupovinaID;
	public $knjigaID;
	public $kolicina;
	public $korisnik;
	public $datum;


	function __construct()
	{

	}
	}
?>
