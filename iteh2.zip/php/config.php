<?php
session_start();
global $SYS_pocdir;
global $SYS_title;
global $SYS_baseurl;
$SYS_pocdir="/projekat/";
$SYS_title="Eyewear";
$SYS_description="Eyewear opis";
$SYS_keywords="naocare,sociva,glasses";
$SYS_baseurl = "localhost";
require "konekcija.php";
?>
