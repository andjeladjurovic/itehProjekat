<?php
/**
*
*/
class Proizvodjac
{
	public $proizvodjacID;
	public $proizvodjacNaziv;
	public $proizvodjacDrzava;


	function __construct()
	{

	}
	}
?>
