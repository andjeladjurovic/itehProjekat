<?php
/**
*
*/
class Naocare
{
	public $naocareID;
	public $naocareNaziv;
	public $naocareGod;
	public $naocareCena;
	public $naocareStanje;
	public $proizvodjacID;

	function __construct()
	{

	}
	}
?>
