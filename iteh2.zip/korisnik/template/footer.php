<div id="main_footer" class="col-lg-12 col-sm-12 col-xs-12" >
    (2020)
</div>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $('.carousel').carousel({
            interval: 5000
        })
    </script>
  </body>
</html>
